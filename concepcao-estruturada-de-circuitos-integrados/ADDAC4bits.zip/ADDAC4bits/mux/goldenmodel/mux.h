#ifndef MUX_H
#define MUX_H
#include <stdio.h>
#include <stdlib.h>
int mux(int *a, int *b, int c, int *saida);
#endif