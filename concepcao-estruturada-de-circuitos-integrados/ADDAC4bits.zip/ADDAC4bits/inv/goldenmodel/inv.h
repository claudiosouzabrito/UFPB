#ifndef INV_H
#define INV_H
#include <stdio.h>
#include <stdlib.h>
void inv(int *a, int *s);
#endif