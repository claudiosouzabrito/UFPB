#ifndef SOMADOR_H
#define SOMADOR_H
#include <stdio.h>
#include <stdlib.h>
void somador(int *a, int *b, int c, int *s, int o);
#endif