#ifndef ACC_H
#define ACC_H
#include <stdio.h>
#include <stdlib.h>
int acc(int clka, int clk, int *a, int *acu, int*s);

#endif