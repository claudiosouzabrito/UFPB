#ifndef MUX_H
#define MUX_H
#include <stdio.h>
#include <stdlib.h>
void mux(int a, int b, int c);
#endif