#ifndef ACC_H
#define ACC_H
#include <stdio.h>
#include <stdlib.h>
void acc(int clka, int clk, int a, int acu);

#endif