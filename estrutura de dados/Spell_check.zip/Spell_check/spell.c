#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define TAMANHO 10000

struct No{	//Lista simplesmente encadeada
	char palavra[47];
	struct No *proximo;
};

typedef struct No *tabelaHash[TAMANHO];

struct Erro{	//Lista duplamente encadeada
    char palavra[47];
    struct Erro *next;
  	struct Erro *back;
  	int lin, col, loc;
};

typedef struct Erro *erro;

void Prepend(struct No **lista, char *c){
	struct No *aux;

	if(!*lista){	//O indice ta livre
		*lista = malloc(sizeof(struct No));
		strcpy((*lista)->palavra, c);
		(*lista)->proximo = NULL;
	}else{	//Casos de colisões
		aux = malloc(sizeof(struct No));
		strcpy(aux->palavra, c);
		aux->proximo = *lista;
		*lista = aux;
	}
}

void IniciaTabelaHash(tabelaHash hash1){ 	//Todos os indices do vetor igual a NULL
	for(int i=0; i<TAMANHO; i++){
		hash1[i] = NULL;
	}
}

//Função de hash 1 
int Hash(char*c){
	int i, j =58, hash = 0;

	for(i = 0; c[i] != '\0'; i++){
		hash += (c[i] - 'A' + 1) * j;  //Cada letra da palavra vai ser multiplicada 
		j += 1;												//por 58, atribuindo um valor a palavra
	}

	if(hash < 0){
		return hash * -1;	// Caso o valor estourar
	}else{
		return hash;
	}
}

//Função de hash 2
/*int Hash(char *c){
	int tamanho = strlen(c), soma = 0;

	for(int i = 0; i < tamanho; i++){
		soma += i * c[i];
	}

	if(soma < 0){
		return soma * -1;	// Caso o valor estourar
	}else{
		return soma;
	}
}*/

//Função de hash 3
/*int Hash(char*c){
	int i, hash = 0;

	for(i = 0; c[i] != '\0'; i++){
		if(i % 2 == 0){
			hash += (c[i] - 'A' + 1) >> i;
		}
	}
  
	if(hash < 0){
		return hash * -1;	// Caso o valor estourar
	}else{
		return hash;
	}
}*/

int Hashcomp(int hash){
	return hash % TAMANHO;
}

void ImprimeTabelaHash(tabelaHash h2){
	int i;
	tabelaHash h1;	//Tabela Hash auxiliar
  
	for( i=0 ; i< TAMANHO ; i++){
		h1[i] = h2[i];
	}
  
	printf("tabelaHash\n");
	for(i = 0; i < TAMANHO; i++){	//Imprime toda a tabela Hash auxiliar == Tabela original
    
		while(h1[i] != NULL){
			printf("%s ", h1[i]->palavra);
			printf("(%d -> %d) ", Hash(h1[i]->palavra),Hashcomp(Hash(h1[i]->palavra)));
			h1[i] = h1[i]->proximo;
		}
                               
		printf("\n");
                               
		if(h1[i] != NULL)
			printf("\n");
	}
}

int total = 0;
int cont = 0;
double tempo;

void comparar(tabelaHash h2, char *palavra, struct Erro **erro1, struct Erro **erro2){
  int i,j=0, Cont=0, errada, col=1, coluna = 1, hash  = 0;
  static int linha = 1, lin = 1;
	char c[47] = "\0";
  
	tabelaHash h1;	//Tabela Hash auxiliar
  
	for(i = 0; i< TAMANHO; i++){
		h1[i] = h2[i];
	}
  
	for(i = 0; palavra[i] != '\0'; i++){ 
		errada=1; //Inicia assumindo que a palavra está errada
		if(palavra[i] != '\n' && palavra[i] != ' ' && palavra[i] != ',' && palavra[i] != '.' && palavra[i] != '!'
			&& palavra[i] != '?' && palavra[i] != '"' && palavra[i] != ')' && palavra[i] != '(' && palavra[i] != ':'
			&& palavra[i] != ';'){	//Caracteres a desconsiderar
			if(j ==0){
				total++;
				linha = lin;
				coluna = col;
			}
			c[j] = palavra[i]; // Vai adicionando palavra por palavra do texto em c;
			j++;
			col++;
		}
		else if(c[0] != '\0'){
			if(palavra[i] == '\n'){
				col = 1;
			}
			else 
        col++;
      
			hash = Hashcomp(Hash(c));
      
			while(h1[Hashcomp(Hash(c))] != NULL){	//Vai consultando todas as palavras da lista encadeada
  			if(strcmp(h1[Hashcomp(Hash(c))]->palavra,c) == 0){	//Se a palavra do texto for igual ao do dicionario
					errada=0;	//Diz que a palavra ta certa
  				break;
				}
  			h1[Hashcomp(Hash(c))] = h1[Hashcomp(Hash(c))]->proximo;
			}
			h1[Hashcomp(Hash(c))] = h2[Hashcomp(Hash(c))];
			if(errada){	//Caso a palavra estiver errada
				cont++;
        struct Erro *erro = (struct Erro*) malloc (sizeof(struct Erro)); 	//Nó auxiliar
				struct Erro *er1 = (struct Erro*) malloc (sizeof(struct Erro));		//Ponteiro do primeiro nó
				struct Erro *er2 = (struct Erro*) malloc (sizeof(struct Erro));		//Ponteiro do ultimo nó
				er1 = *erro1;
				strcpy(erro->palavra, c);
				erro->loc = cont;
				erro->col = coluna;
				erro->lin = lin;
				erro->back = NULL;
				erro->next = er1;
				er1->back = erro;
				if(!er1->next) *erro2 = erro; //se a lista tava vazia, o ultimo ponteiro vai apontar para esse nó tbm
				*erro1 = erro;
				er1 = *erro1;
    	}
    	for(int k=0; k <= j; k++) c[k] = '\0';
				j = 0;
  	}
  }

  lin++;
}

void MostrarErro(FILE *saida, struct Erro *erro){ 
  
		fprintf(saida, "Numero total de palavras do texto %d\n", total);
		fprintf(saida, "Tempo total da verificação: %lf\n", tempo);
		fprintf(saida, "Numero de palavras que falharam no spell check: %d\n", cont);
		fprintf(saida, "Lista de palavras que falharam no spell check:\n");
		fprintf(saida, "\nNumero de ocorrencias - Palavra : Linha, Coluna\n");
		fprintf(saida, "-----------------------------------------------\n");

  	while(erro){
      fprintf(saida,"%d - %s : %d, %d\n", erro->loc, erro->palavra, erro->lin, erro->col);
      erro = erro->back;
    }
}

void InserirDicionario(tabelaHash hash1, char *palavra){
	int i, j = 0, k, count=0;
	char c[47] = "\0";	//Maior palavra 
	for(i = 0; palavra[i] != '\0'; i++)
  {
    if(palavra[i] == '\r'){// Para poder pegar a última palavra
			continue;
		}
    
		if(palavra[i] != '\n')
    {
			c[j] = palavra[i];
			j++;
		}else
    {
			c[j] = '\0';
			Prepend(&hash1[Hashcomp(Hash(c))], c);	//Adiciona a palvra a o indice previamente calculado.
			for(k = 0; k < 47; k++) 
        c[k] = '\0';
      
			j=0;
		}
	}
}

void Imprimecolisoes(tabelaHash h1, int *colisoes, FILE *csv){
	int elementosNoBucket = 0;
	tabelaHash h2;	//Tabela Hash auxiliar

	for(int i = 0; i < TAMANHO; i++){
		h2[i] = h1[i];
	}
	for(int i=0; i< TAMANHO; i++){
		while(h1[i] != NULL){
			elementosNoBucket++;
			h1[i] = h1[i]->proximo;	//Percorrer a lista
		}
		colisoes[i] = elementosNoBucket;
		fprintf(csv, "bucket[%d]: colisoes : %d\n", i, colisoes[i]);
		elementosNoBucket = 0;
	}

	for(int i = 0; i < TAMANHO; i++){
		h1[i] = h2[i];
	}

}

int main(void){
	struct No *lista = NULL;
	tabelaHash hash1;
	struct Erro *erro1 = (struct Erro*)  malloc (sizeof(struct Erro));
	struct Erro *erro2 = (struct Erro*)  malloc (sizeof(struct Erro));
	erro1->next = NULL;
	int colisoes[TAMANHO] = {0};
	char palavra[47] = "\0", fraseParaTeste[200] = "\0";
	int quantBucketsComColisoes = 0;
	int maiorColisao = 0;
	int bucketMaiorColisao = 0;
	int quantBucketsUsados = 0;

  FILE *dicionario, *textoTeste, *saida, *csv;	//Arquivo do dicionario
	dicionario = fopen("dicionario.txt", "r");
	textoTeste = fopen("texto.txt", "r");
	saida = fopen("saida.txt", "w");
	csv = fopen("saida.csv", "w");
  if(csv != NULL){
		puts("Arquivo csv aberto com sucesso");
	}
	if(dicionario != NULL){
		puts("Arquivo dicionario aberto com sucesso");
	}

	if(textoTeste != NULL){
		puts("Arquivo texto aberto com sucesso");
	}


	IniciaTabelaHash(hash1);
	while(!feof(dicionario)){
		fgets(palavra, 47, dicionario);
		InserirDicionario(hash1, palavra);
	}

  Imprimecolisoes(hash1, colisoes, csv);

	for(int i = 0; i < TAMANHO; i++){
		if(colisoes[i] >= 1){
			quantBucketsUsados++;
		}
	 	if(colisoes[i] > 1){
	 		quantBucketsComColisoes++;
	 		if(colisoes[i] > maiorColisao){
	 			maiorColisao = colisoes[i];
	 			bucketMaiorColisao = i;
	 		}
	 	}
	}
  
  	printf("Funcao de hash 1\n");
	printf("Sao %d buckets com colisoes\n", quantBucketsComColisoes);
	printf("O bucket %d possui a maior quantidade de colisoes, %d\n", bucketMaiorColisao, maiorColisao);
	printf("Foram usados %d buckets de %d\n", quantBucketsUsados, TAMANHO);
  
  clock_t Ticks[2];
  Ticks[0] = clock();
  //O código começa a ser medido neste ponto.

	while(!feof(textoTeste)){
		fgets(fraseParaTeste, 200, textoTeste);
		comparar(hash1, fraseParaTeste, &erro1, &erro2);
	}

	Ticks[1] = clock();
  double Tempo = ((Ticks[1] - Ticks[0]) * 1000/ CLOCKS_PER_SEC);
  printf("Tempo gasto: %g ms.\n", Tempo);
  tempo = Tempo;
  
  MostrarErro(saida, erro2);

	fclose(dicionario);
	fclose(textoTeste);
	fclose(saida);
  

  
	return 0;
}